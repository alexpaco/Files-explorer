var body = document.getElementsByTagName("body")[0];
var popup = document.getElementById("content-popup");
var popupCover = document.getElementById("cover-popup");
var closePopup = document.getElementById("close-popup");
var errorMessage = document.getElementById("error-message");

var form = document.getElementById("newsletter-form"); //Je déclare au début du code toutes les variables dont j'aurai besoin.


//Ensuite je crée mes fonctions

function validateEmail(email) { //Cette fonction vérifie que l'email est valide avec des regex. + d'infos https://openclassrooms.com/courses/concevez-votre-site-web-avec-php-et-mysql/memento-des-expressions-regulieres
  var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return regex.test(email);
}

function fadeIn(elem,maxOpacity) { //Cette fonction anime l'opacité jusqu'à une certaine valeur maxOpacity
	elem.style.opacity = 0;

	var animation = setInterval(function(){ //setInterval lance un code toutes les x secondes (ici, toutes les 50 millisecondes comme on le voit ligne 28)
		
		if(elem.style.opacity >= maxOpacity) {
			clearInterval(animation);
		} //Si l'opacité max est atteinte, on arrête de lancer le code toutes les x secondes avec clearInterval
		else {
			elem.style.opacity = parseFloat(elem.style.opacity) + 0.05;
		} //Si l'opacité max n'est pas encore atteinte, on ajoute de l'opacité
		
	},50);
}

function fadeOut(elem) { //Même principe que la fonction fadeIn, inversée pour faire disparaitre un élément. Il n'y a qu'un paramètre car l'opacité max est forcément 0

	var animation = setInterval(function(){
		if(elem.style.opacity <= 0) {
			clearInterval(animation);
		}
		else {
			elem.style.opacity = parseFloat(elem.style.opacity) - 0.05;
		}
	},50);
}

function popUpOpen() {
	fadeIn(popup,1); //La fonction popUpOpen lance la fonction fadeIn sur l'élement "popup" avec une opacité max de 1 (pas de transparence)
	fadeIn(popupCover,0.5);	//Pareil sur l'élement cover-popup, avec une opacité max de 0.5 (semi-transparent)
}

function popUpClose() {
	fadeOut(popup);
	fadeOut(popupCover);
}


body.onload = function() {
	setTimeout(popUpOpen, 1000);
} //On écoute l'évènement "body a fini de charger", puis on lance la fonction popUpOpen après 1seconde d'attente

closePopup.onclick = function() {
	popUpClose();
} //Au clic sur la croix, on lance la fonction popupClose() qui va elle-même lancer la fonction fadeOut() sur les 2 élements


form.onsubmit = function(e) { //Lorsque l'évènement "formulaire soumis" se déclenche - Ici la variable e contient l'évènement "formulaire soumis"

	var email =  document.getElementById("email").value; //On récupère la valeur entrée dans l'input email.

	e.preventDefault(); //On empêche le comportement par défaut de l'évènement qui est "soumettre le formulaire". On le soumettra manuellement si l'email est OK

	if(email.length <= 0) { //On test si le champ email est vide

		
		errorMessage.innerHTML = "Ce champ est obligatoire";
		errorMessage.style.visibility = "visible";

	}
	else if(!validateEmail(email)) { //On test si la fonction validateEmail retourne false (= email invalide)

		errorMessage.innerHTML = "Veuillez entrer un email valide";
		errorMessage.style.visibility = "visible";

	}
	else {	//Si l'email est ok (aucun des cas ci-dessus), on envoie le formulaire.

		this.submit();

	}
}
