<!DOCTYPE html>
<html>
	<head>

		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="style.css">
		
		<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

	</head>

	<body>
		<section>

			<h1>Merci</h1>
	
			<p>Le formulaire a bien été soumis</p>

		</section>

		<div id="cover-popup"></div>

		<section id="content-popup">

			<div id="close-popup">
				<i class="fa fa-window-close"></i>
			</div>

			<form id="newsletter-form" action=merci.php" method="post">
				<h1>Inscrivez-vous à la newsletter</h1>
				<label for="email">Email : </label><input placeholder="votre email" type="email" name="email" id="email">
				<input type="submit" name="submitBtn">
			</form>

		</section>

	</body>
</html>
